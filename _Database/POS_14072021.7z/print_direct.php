<?php
$outprint = 'Test Printer';
$printer = printer_open(nama printer);
printer_write($printer, $outprint );
printer_close($printer);
?>