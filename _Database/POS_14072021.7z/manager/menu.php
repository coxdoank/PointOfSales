<div id="sidebar"><a href="#" class="visible-phone"><i class="icon icon-home"></i> Dashboard</a>
  	<ul>
    <li><a href="./"><i class="icon icon-home"></i> <span>Dashboard</span></a> </li>
    <li class="submenu"><a href="#"><i class="icon icon-th-list"></i> <span>Master</span></a>
      <ul>
        <li><a href="ms_category.php">Master Category</a></li>
        <li><a href="ms_item.php">Master Item</a></li>
        <li><a href="ms_user.php">Management User</a></li>
        <li><a href="ms_aplikasi.php?act=edit&id=1">Pengaturan Aplikasi</a></li>
      </ul>
	</li>
	</ul>
</div>	